<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    // Redirect to login if the user is not logged in
    header('Location: login.php');
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "canteen"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cart items for the logged-in user
$user_id = $_SESSION['user_id']; // Get logged-in user's ID from session
$sql = "SELECT * FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Debug: Check if there are any results
if ($result->num_rows > 0) {
    // Debug: Output number of items in the cart
    echo "<!-- Debug: Number of items in cart: " . $result->num_rows . " -->";
} else {
    // Debug: No items found
    echo "<!-- Debug: No items found in cart for user ID " . $user_id . " -->";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Your Cart</h2>
        <div class="row">
            <?php
            if ($result->num_rows > 0) {
                // Output each cart item
                while ($row = $result->fetch_assoc()) {
                    echo '
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="' . htmlspecialchars($row['item_image']) . '" class="card-img-top" alt="' . htmlspecialchars($row['item_name']) . '">
                            <div class="card-body">
                                <h5 class="card-title">' . htmlspecialchars($row['item_name']) . '</h5>
                                <p class="card-text">' . htmlspecialchars($row['item_description']) . '</p>
                                <p class="card-text"><strong>Price: ₹' . number_format($row['item_price'], 2) . '</strong></p>
                                <button class="btn btn-danger remove-item" data-id="' . htmlspecialchars($row['cart_id']) . '">Remove</button>
                            </div>
                        </div>
                    </div>';
                }
            } else {
                echo '<p>Your cart is empty.</p>';
            }
            ?>
        </div>

        <!-- Link to Checkout -->
        <?php if ($result->num_rows > 0): ?>
            <a href="checkout.php" class="btn btn-success mt-4">Proceed to Checkout</a>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle removing an item from the cart
        $(document).on('click', '.remove-item', function() {
            const cartId = $(this).data('id');

            $.ajax({
                url: 'remove_from_cart.php',
                method: 'POST',
                data: { cart_id: cartId },
                success: function(response) {
                    alert('Item removed from cart');
                    location.reload(); // Reload page to update cart
                },
                error: function() {
                    alert('Failed to remove item. Please try again.');
                }
            });
        });
    </script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
