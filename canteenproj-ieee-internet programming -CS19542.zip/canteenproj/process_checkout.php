<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Set the correct timezone
date_default_timezone_set('Asia/Kolkata');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "canteen"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user information
$user_id = $_SESSION['user_id'];

// Retrieve `roll_no` from form
$roll_no = $_POST['roll_no']; 

// Fetch user's email
$userSql = "SELECT email FROM users WHERE user_id = ?";
$userStmt = $conn->prepare($userSql);
$userStmt->bind_param("i", $user_id);
$userStmt->execute();
$userResult = $userStmt->get_result();
$userInfo = $userResult->fetch_assoc();
$email = $userInfo['email'];

// Fetch cart items for the user
$cartSql = "SELECT item_name, item_price FROM cart WHERE user_id = ?";
$cartStmt = $conn->prepare($cartSql);
$cartStmt->bind_param("i", $user_id);
$cartStmt->execute();
$cartResult = $cartStmt->get_result();

$total_price = 0;
$order_details = '';

// Prepare the order details and calculate the total price
while ($row = $cartResult->fetch_assoc()) {
    $total_price += $row['item_price'];
    $order_details .= '<tr>
        <td>' . htmlspecialchars($row['item_name']) . '</td>
        <td>₹' . number_format($row['item_price'], 2) . '</td>
    </tr>';
}

// Insert the order into the orders table
$order_date = date('Y-m-d H:i:s'); 
$sql = "INSERT INTO orders (user_id, total_price, order_date) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ids", $user_id, $total_price, $order_date);

if ($stmt->execute()) {
    // Clear the user's cart after placing the order
    $clearCartSql = "DELETE FROM cart WHERE user_id = ?";
    $clearStmt = $conn->prepare($clearCartSql);
    $clearStmt->bind_param("i", $user_id);
    $clearStmt->execute();
    $clearStmt->close();

    // Format the order date for better readability
    $formatted_date = date('d M Y, h:i A', strtotime($order_date)); 

    // Generate the bill with Bootstrap
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bill Summary</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container mt-5">
            <h1 class="text-center">Bill Summary</h1>
            <div class="card">
                <div class="card-body">
                    <p><strong>Order Date:</strong> ' . htmlspecialchars($formatted_date) . '</p>
                    <p><strong>Roll No:</strong> ' . htmlspecialchars($roll_no) . '</p>
                    <p><strong>Email:</strong> ' . htmlspecialchars($email) . '</p>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            ' . $order_details . '
                            <tr>
                                <td><strong>Total Price</strong></td>
                                <td><strong>₹' . number_format($total_price, 2) . '</strong></td>
                            </tr>
                        </tbody>
                    </table>
                    <p class="text-center">Thank you for your order!</p>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
    </html>';

} else {
    echo "Error placing the order. Please try again.";
}

$stmt->close();
$conn->close();
?>
