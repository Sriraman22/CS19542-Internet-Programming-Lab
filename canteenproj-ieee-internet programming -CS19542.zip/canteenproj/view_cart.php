<?php
session_start();
include 'db.php'; // Ensure this file connects to your database

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo '<p>Please log in to view your cart.</p>';
    exit;
}

// Get the user ID from session
$user_id = $_SESSION['user_id']; // Use session user ID

$sql = "SELECT cart_id, item_name, item_description, item_price, item_image FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '
        <div class="col-md-4">
            <div class="card">
                <img src="' . htmlspecialchars($row['item_image']) . '" class="card-img-top" alt="' . htmlspecialchars($row['item_name']) . '">
                <div class="card-body">
                    <h5 class="card-title">' . htmlspecialchars($row['item_name']) . '</h5>
                    <p class="card-text">' . htmlspecialchars($row['item_description']) . '</p>
                    <p class="card-text"><strong>Price: ₹' . number_format($row['item_price'], 2) . '</strong></p>
                    <button class="btn btn-danger remove-item" data-id="' . $row['cart_id'] . '">Remove</button>
                </div>
            </div>
        </div>';
    }
} else {
    echo '<p>Your cart is empty.</p>';
}

$stmt->close();
$conn->close();
?>
