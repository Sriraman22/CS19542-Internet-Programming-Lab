<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "canteen"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Hardcoded admin credentials
    $admin_username = "sriram"; // Admin username
    $admin_password = "abcd"; // Admin password

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the entered credentials match the hardcoded values
    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin_id'] = $admin_username; // You can store a specific admin ID if needed
        header('Location: admin_dashboard.php');
        exit();
    } else {
        echo "Invalid login details.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Admin Login</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>
</body>
</html>
