<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in as admin
    header('Location: admin_login.php');
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "canteen"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add or update product stock
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_id = $_POST['item_id'];
    $stock_count = $_POST['stock_count'];

    $sql = "UPDATE menu SET stock_count = ? WHERE item_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $stock_count, $item_id);
    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Stock updated successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error updating stock.</div>";
    }
}

// Fetch all menu items
$menuSql = "SELECT * FROM menu";
$menuResult = $conn->query($menuSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Admin Dashboard</h1>
        <h3>Menu Item Price, Stock, Action</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $menuResult->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['item_name']); ?></td>
                    <td>₹<?php echo number_format($row['price'], 2); ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="item_id" value="<?php echo $row['item_id']; ?>">
                            <input type="number" name="stock_count" min="0" value="<?php echo $row['stock_count']; ?>" required>
                    </td>
                    <td>
                            <button type="submit" class="btn btn-primary">Update Stock</button>
                        </form>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
