<?php
include 'db.php'; // Ensure this file connects to your database

// Get cart_id from the AJAX request
if (isset($_POST['cart_id'])) {
    $cart_id = $_POST['cart_id'];

    // Delete the item from the cart
    $stmt = $conn->prepare("DELETE FROM cart WHERE cart_id = ?");
    $stmt->bind_param("i", $cart_id);

    if ($stmt->execute()) {
        echo "Item removed successfully";
    } else {
        echo "Error removing item";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "No cart ID provided.";
}
?>
