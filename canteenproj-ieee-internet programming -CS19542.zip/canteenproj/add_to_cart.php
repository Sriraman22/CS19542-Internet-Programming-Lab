<?php
session_start();
include 'db.php'; // Ensure this file connects to your database

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; // Get user_id from session
} else {
    echo "User not logged in.";
    exit;
}

// Check if request is POST and required data is present
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    // Insert the item into the cart table
    $stmt = $conn->prepare("INSERT INTO cart (user_id, item_name, item_description, item_price, item_image) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issds", $user_id, $name, $description, $price, $image);

    if ($stmt->execute()) {
        echo "Item added to cart!";
    } else {
        echo "Error: Could not add item to cart.";
    }

    $stmt->close();
    $conn->close();
}
?>
