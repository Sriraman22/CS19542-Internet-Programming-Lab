<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header('Location: login.php');
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "canteen"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cart items for the logged-in user
$user_id = $_SESSION['user_id']; // User ID from session
$sql = "SELECT * FROM cart WHERE user_id = '$user_id'";
$result = $conn->query($sql);

// Initialize total price
$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Checkout</h2>
        <div class="row">
            <div class="col-md-8">
                <h4>Your Cart Items</h4>
                <ul class="list-group">
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $total_price += $row['item_price'];
                            echo '
                            <li class="list-group-item">
                                <div class="row">
                                    <div class="col-md-4">
                                        <img src="' . $row['item_image'] . '" class="img-fluid" alt="' . $row['item_name'] . '">
                                    </div>
                                    <div class="col-md-8">
                                        <h5>' . $row['item_name'] . '</h5>
                                        <p>' . $row['item_description'] . '</p>
                                        <strong>Price: ₹' . number_format($row['item_price'], 2) . '</strong>
                                    </div>
                                </div>
                            </li>';
                        }
                    } else {
                        echo '<li class="list-group-item">Your cart is empty.</li>';
                    }
                    ?>
                </ul>
                <h4 class="mt-3">Total: ₹<?php echo number_format($total_price, 2); ?></h4>
            </div>

            <div class="col-md-4">
                <h4>Billing Details</h4>
                <form action="process_checkout.php" method="POST">
                    <div class="form-group">
                        <label>Roll number</label>
                        <input type="number" name="roll_no" class="form-control" required>
                    </div>
                   
                    <div class="form-group">
                        <label>Payment Method</label>
                        <select name="payment_method" class="form-control" required>
                            <option value="cash_on_delivery">Cash on Delivery</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="debit_card">Debit Card</option>
                        </select>
                    </div>
                    <input type="hidden" name="total_price" value="<?php echo $total_price; ?>">
                    <button type="submit" class="btn btn-success btn-block">Place Order</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
