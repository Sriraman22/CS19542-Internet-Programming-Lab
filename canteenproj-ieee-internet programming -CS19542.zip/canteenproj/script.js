// Sample menu data (this would come from a database in a real scenario)
const menuData = [
    { name: 'chapathi', description: 'A delicious chapathi with curry.', price: 15, image: 'image/chapathi.jpg' },
    { name: 'veg biriyani', description: 'A flavorful vegetable biriyani.', price: 50, image: 'image/veg biriyani.jpeg' },
    { name: 'parotta', description: 'Flaky parotta served with curry.', price: 20, image: 'image/download.jpeg' },
    { name: 'veg Pasta', description: 'Creamy Alfredo pasta with corn and carrots.', price: 50, image: 'image/pasta.jpeg' },
    { name: 'egg pasta', description: 'Pasta served with scrambled eggs.', price: 60, image: 'image/egg pasta.jpeg' },
    { name: 'sambar rice', description: 'Rice served with traditional sambar.', price: 60, image: 'image/sambar rice.jpeg' },
    { name: 'veg fried rice', description: 'Vegetable fried rice with spices.', price: 60, image: 'image/fried rice.jpeg' },
    { name: 'egg fried rice', description: 'Fried rice with eggs and vegetables.', price: 60, image: 'image/egg fried rice.jpeg' },
    { name: 'water bottle', description: 'Purified Himalayan drinking water.', price: 20, image: 'image/waterbottle.jpeg' }
];

// Function to display menu items dynamically
function displayMenu(menuItems) {
    const menuContainer = $('#menuItems');
    menuContainer.empty(); // Clear existing items

    menuItems.forEach(item => {
        const menuItem = `
            <div class="col-md-4">
                <div class="card">
                    <img src="${item.image}" class="card-img-top" alt="${item.name}">
                    <div class="card-body">
                        <h5 class="card-title">${item.name}</h5>
                        <p class="card-text">${item.description}</p>
                        <p class="card-text"><strong>Price: Rs.${item.price.toFixed(2)}</strong></p>
                        <button class="btn btn-primary order-now" data-item='${JSON.stringify(item)}'>Order Now</button>
                    </div>
                </div>
            </div>
        `;
        menuContainer.append(menuItem);
    });
}

// Handle "Order Now" button clicks
$(document).ready(function() {
    // Initial display of all menu items
    displayMenu(menuData);

    // Search functionality
    $('#searchInput').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        const filteredMenu = menuData.filter(item => item.name.toLowerCase().includes(searchTerm));
        displayMenu(filteredMenu); // Update the displayed menu items
    });

    // Handle "Order Now" button click and send data to PHP via AJAX
    $(document).on('click', '.order-now', function(e) {
        e.preventDefault();

        // Get the item data from the button
        const item = JSON.parse($(this).attr('data-item'));

        // AJAX call to add the item to the cart (user_id handled in PHP)
        $.ajax({
            url: 'add_to_cart.php',
            method: 'POST',
            data: {
                name: item.name,
                description: item.description,
                price: item.price,
                image: item.image
            },
            success: function(response) {
                alert(item.name + ' has been added to your cart.');
            },
            error: function() {
                alert('Failed to add item to cart. Please try again.');
            }
        });
    });

    // Fetch and display cart items when "View Cart" is clicked
    $('#cartModal').on('show.bs.modal', function(e) {
        $.ajax({
            url: 'view_cart.php', // The PHP file to fetch cart items (should check session user_id)
            method: 'GET',
            success: function(response) {
                $('#cartItems').html(response); // Update the cart items in the modal
            },
            error: function() {
                alert('Failed to fetch cart items.');
            }
        });
    });

    // Handle removing an item from the cart
    $(document).on('click', '.remove-item', function() {
        const cartId = $(this).data('id');

        $.ajax({
            url: 'remove_from_cart.php',
            method: 'POST',
            data: { cart_id: cartId },
            success: function(response) {
                alert('Item removed from cart');
                location.reload(); // Reload page to update cart
            },
            error: function() {
                alert('Failed to remove item. Please try again.');
            }
        });
    });
});
